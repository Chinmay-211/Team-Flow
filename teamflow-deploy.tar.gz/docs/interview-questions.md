# TeamFlow — Technical Interview Q&A Preparation Guide

This guide contains deep, technical, candidate-level answers for all interview questions across **React.js, Node.js, Redis, OpenSearch, SNS/SQS, ECS/Fargate, ALB, IAM, and CloudWatch**.

---

## 1. React.js

### Q1: Why React?
**Answer**: React provides a declarative, component-driven paradigm with a Virtual DOM that optimizes rendering updates. Its unidirectional data flow makes state predictable and easy to trace across complex dashboards like TeamFlow's Kanban boards.

### Q2: State management approach?
**Answer**: We use React Context API combined with custom hooks (`useAuth`) for global authentication and user state, while keeping UI ephemeral state (such as active modals, form inputs, and upload progress bars) local to individual components. This avoids over-engineering global state stores while preventing unnecessary root re-renders.

### Q3: How does React rendering work?
**Answer**: React renders in two phases: the **Render Phase** (building the Virtual DOM tree and diffing changes via Reconciliation algorithm) and the **Commit Phase** (applying minimal calculated DOM mutations). In TeamFlow, updating a task status only re-renders the affected Kanban card column.

### Q4: Why use React Router?
**Answer**: React Router v7 enables client-side Single Page Application (SPA) routing without full page reloads. It supports URL parameter parsing (`/projects/:id`), search parameters (`?task=123`), and dynamic route protection via wrapping layouts.

### Q5: How do you handle API errors?
**Answer**: We centralize API requests through an Axios instance equipped with response interceptors. Status `401 Unauthorized` automatically purges expired JWT tokens from `localStorage` and redirects the user to `/login`, while validation errors (`400`) display friendly contextual banners.

### Q6: How do you protect routes?
**Answer**: Using a higher-order `<ProtectedLayout>` wrapper component that checks the `AuthContext` state. If no valid user token exists, it renders a `<Navigate to="/login" replace />` guard.

### Q7: How do you optimize rendering?
**Answer**: By memoizing list items, decoupling heavy modals using conditional mounting, avoiding global re-renders for localized component state, and using Vite for fast HMR and lightweight bundle splitting.

---

## 2. Node.js & Express

### Q1: Why Node.js?
**Answer**: Node.js utilizes a non-blocking, event-driven I/O model running on V8 engine, making it ideal for I/O-intensive collaboration applications with high concurrent HTTP calls, database queries, and async AWS service invocations.

### Q2: How does the event loop work?
**Answer**: The Event Loop runs in single-threaded phases: **Timers** (`setTimeout`), **Pending I/O callbacks**, **Idle/Prepare**, **Poll** (retrieving new I/O events), **Check** (`setImmediate`), and **Close callbacks**. Microtasks (`Promise.then`, `process.nextTick`) drain completely after every phase.

### Q3: Why Express?
**Answer**: Express is a minimalist, unopinionated web framework providing robust middleware chaining, request routing, and error handling.

### Q4: What is Middleware?
**Answer**: Functions with signature `(req, res, next)` that execute sequentially during the request-response lifecycle. In TeamFlow, we chain `helmet` (security headers) → `cors` → `express.json()` → `authenticate` (JWT) → `authorizeProjectRole` → `validate(schema)` → Controller handler.

### Q5: Async/await?
**Answer**: Syntactic sugar over JavaScript Promises that allows asynchronous code to be written synchronously, combined with `try/catch` or centralized Express error middleware for clean error propagation.

### Q6: Error handling?
**Answer**: Custom `AppError` subclasses (`NotFoundError`, `ForbiddenError`, `ValidationError`) passed to Express `next(err)` and caught by a 4-argument centralized error middleware (`err, req, res, next`) returning structured JSON error payloads.

### Q7: Authentication strategy?
**Answer**: Stateless JWT (JSON Web Tokens) signed with HMAC SHA-256 (`JWT_SECRET`) containing user ID and expiration claims, alongside bcrypt password hashing with 10 salt rounds.

### Q8: REST API design?
**Answer**: Resource-oriented URLs (`/api/projects/:id/tasks`), standardized HTTP verbs (`GET`, `POST`, `PUT`, `DELETE`, `PATCH`), proper status codes (`200`, `201`, `400`, `401`, `403`, `404`, `500`), and consistent JSON envelope responses.

---

## 3. Redis Caching

### Q1: Why Redis?
**Answer**: Redis is an in-memory key-value store providing sub-millisecond read latency. We use it to reduce PostgreSQL query load for dashboard metric aggregations and OpenSearch queries.

### Q2: What is caching?
**Answer**: Storing computed query results in fast in-memory storage so subsequent identical requests are served instantly without querying the primary database.

### Q3: Cache invalidation strategy?
**Answer**: We use **Time-To-Live (TTL)** expiration (60s for dashboards, 120s for search) coupled with **Event-Driven Write Invalidation** (when a project/task is updated or assigned, `RedisService.invalidateDashboard()` deletes stale keys).

### Q4: What happens when Redis goes down?
**Answer**: TeamFlow is designed for high availability and graceful fallback. If Redis fails, our wrapper safely catches the connection error and proceeds directly to query PostgreSQL/OpenSearch without crashing the application.

---

## 4. Amazon OpenSearch

### Q1: Why OpenSearch instead of PostgreSQL?
**Answer**: PostgreSQL `ILIKE` queries require sequential table scans across multiple tables and lack fuzzy matching or relevance scoring. OpenSearch uses an inverted index with BM25 scoring for instant full-text search across titles, descriptions, and comments.

### Q2: Full-text search mechanism?
**Answer**: Text fields are tokenized, stemmed, and indexed into an inverted index mapping tokens to document IDs. Multi-match queries search across `title^3` (boosted), `projectName^2`, and `content`.

### Q3: Index structure?
**Answer**: We maintain a `teamflow-content` index storing document type (`project`, `task`, `comment`), project ID, title, description, and creation timestamps.

### Q4: What happens if OpenSearch is unavailable?
**Answer**: The system automatically falls back to PostgreSQL case-insensitive query matching (`mode: 'insensitive'`) so search functionality remains active.

---

## 5. Amazon SNS & SQS

### Q1: Why SNS?
**Answer**: Amazon Simple Notification Service (SNS) provides a pub/sub fan-out messaging system allowing the API to publish event notifications without coupling to downstream processors.

### Q2: Why SQS?
**Answer**: Amazon Simple Queue Service (SQS) provides durable message queuing that decouples the producer API from background workers, allowing message buffering and rate smoothing.

### Q3: Why use both (SNS → SQS)?
**Answer**: This is the classic **Fan-Out Pattern**. SNS allows publishing a single event (e.g. `TASK_ASSIGNED`), which can be subscribed to by multiple SQS queues (notifications queue, analytics queue, audit log queue) independently.

### Q4: What happens if a worker crashes?
**Answer**: If a worker fails to acknowledge/delete a message within the **Visibility Timeout** (30s), SQS automatically makes the message visible again for another worker instance to pick up.

### Q5: Message retry & Dead-Letter Queue (DLQ)?
**Answer**: Unprocessable messages that fail maxReceiveCount retries (e.g. 5 times) are automatically routed to a Dead-Letter Queue (DLQ) for inspection without blocking the primary queue.

### Q6: Idempotency?
**Answer**: Workers check existing records before creating duplicate notifications to ensure receiving a duplicated message multiple times produces the exact same state.

---

## 6. ECS / Fargate & Infrastructure

### Q1: What is ECS & Fargate?
**Answer**: Amazon Elastic Container Service (ECS) is AWS's fully managed container orchestration service. AWS Fargate is a serverless compute engine for ECS that eliminates the need to provision or manage EC2 instances.

### Q2: Why Fargate over EC2?
**Answer**: Fargate removes infrastructure management overhead (OS patching, instance scaling, AMI updates) and bills strictly per vCPU/RAM per second consumed by containers.

### Q3: Task vs Service?
**Answer**: A **Task Definition** is the blueprint for containers (Docker image, CPU, RAM, environment vars). A **Task** is a running instance. An **ECS Service** maintains the desired count of running tasks, integrating with ALB target groups.

### Q4: ALB (Application Load Balancer)?
**Answer**: Operates at Layer 7 (HTTP/HTTPS), distributing incoming web traffic across ECS Fargate tasks using target group health checks (`GET /health`).

### Q5: IAM & Least Privilege?
**Answer**: We separate the **Task Execution Role** (pulling ECR images, pushing CloudWatch logs) from the **Task Role** (API permissions for S3/SNS, Worker permissions for SQS/OpenSearch).

### Q6: CloudWatch Logging?
**Answer**: Container stdout/stderr streams are piped to AWS CloudWatch Logs using the `awslogs` log driver for centralized monitoring and log analysis.
